package com.example.fypmypinterview;

public class jdKeywords {
    private final String jdkeyword;

    public jdKeywords(String jdkeyword) {
        this.jdkeyword = jdkeyword;
    }

    public String getJdkeyword() {
        return jdkeyword;
    }
}
