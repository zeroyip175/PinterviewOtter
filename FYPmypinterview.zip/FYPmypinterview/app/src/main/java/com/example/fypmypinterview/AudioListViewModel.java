package com.example.fypmypinterview;

import androidx.lifecycle.ViewModel;

public class AudioListViewModel extends ViewModel {
    // TODO: Implement the ViewModel

}